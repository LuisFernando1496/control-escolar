<div class="content-firm diagonal">
    <div class="titulo-m text-center">
        <span> OBSERVACIONES O RECOMENDACIONES GENERALES DEL DOCENTE</span>
    </div>
    <div class="list-obs ">
        <span>PRIMER PERIODO</span>
    </div>
    <div class="list-obs ">
        <span>SEGUNDO PERIODO</span>
    </div>
    <div class="list-obs" style="border-width: 0px">
        <span>TERCER PERIODO</span>
    </div>
</div>
<div class="row" style="margin-top: 1rem;">
    <div style="float: left;
            width: 20%;">
       <span style="font-size: 10px;"> Folio: <strong>BE07200140099</strong></span>
    </div>
    <div style="float: left;
            width: 20%;">
        <strong>SIN OFICIALIZAR</strong>
    </div>
    <div style="float: left;
            width: 40%;">
        <strong style="text-size: 40px; font-size: 15px;">Fecha de impresion:2020-12-07 19:12:24</strong>
    </div>
    <div style="float: left;
            width: 20%;">
        <strong style="font-size: 12px;">Matricula: 11BXP955</strong>
    </div>
</div>
<div style="margin-left: auto;
    margin-right: auto;
     width: 49rem;
    "> 
    <span style="font-size: 13px;">SE SANCIONARÁ A QUIEN CON DOLO O FINES LUCRATIVOS REPRODUZCA TOTAL O PARCIALMENTE
        ESTE
        FORMATO</span> <br />
</div>
<div style="margin-left: auto;>
    margin-right: auto;
    width: 95%;
    font-size: 12;
    padding-top: 1rem;

    ">
    <span>Para cualquier duda sobre la autenticidad de esta boleta, consultar la siguiente pagina de
        internet: reportes.educacionchiapas.gob.mx</span>
</div>

{{-- <div class="page-break"></div> --}}


<style>
    /* estilos para poner las observaciones de los alumnos  */
    .content-firm {
        position: relative;
        border: 1px solid #000;
        height: 57rem;
    }

    .ocultar-border {
        border-width: 4rem;
    }

    .titulo-m {
        background-color: whitesmoke;
        border-bottom: 1px solid black;
    }

    .obs {
        border-bottom: 1px solid blue;
    }

    .v {
        transform: rotate(-90deg);
    }

    .list-obs {
        height: 20rem;
        border-bottom: 1px solid black;
    }

    .text-md {
        font-size: 12px;
    }

    .footer-end {
        margin-top: 2rem;
    }

</style>
