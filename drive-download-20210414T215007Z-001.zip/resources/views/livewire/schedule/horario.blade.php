<div>
    @if ($keyOne == 0)
        <td rowspan="2" class="text-xs w-20 bg-blue-200">
            08:00 - 09:00
        </td>
    @endif
    @if ($keyOne == 1)
        <td rowspan="2" class="text-xs w-20 bg-blue-200">
            09:00 - 10:00
        </td>
    @endif
    @if ($keyOne == 2)
        <td rowspan="2" class="text-xs w-20 bg-blue-200">
            10:00 - 11:00
        </td>
    @endif
    @if ($keyOne == 3)
        <td rowspan="2" class="text-xs w-20 bg-blue-200">
            11:00 - 11:30
        </td>
    @endif
    @if ($keyOne == 4)
        <td rowspan="2" class="text-xs w-20 bg-blue-200">
            11:30 - 12:30
        </td>
    @endif
    @if ($keyOne == 5)
        <td rowspan="2" class="text-xs w-20 bg-blue-200">
            12:30 - 13:30
        </td>
    @endif
    @if ($keyOne == 6)
        <td rowspan="2" class="text-xs w-20 bg-blue-200">
            13:30 - 14:30
        </td>
    @endif
</div>
