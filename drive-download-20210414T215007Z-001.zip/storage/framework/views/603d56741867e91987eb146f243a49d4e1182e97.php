<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/yamile/Documents/Residencia/FINAL/telesis/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>