
<img src="<?php echo e(Storage::url(\App\Models\School::all()->first()->logo)); ?>" <?php echo e($attributes); ?>>

<?php /**PATH /Users/yamile/Documents/Residencia/FINAL/telesis/resources/views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>