<a href="/">
    
    <img src="<?php echo e(Storage::url(\App\Models\School::all()->first()->logo)); ?>" width="200px" <?php echo e($attributes); ?>>
</a>
<?php /**PATH /Users/yamile/Documents/Residencia/FINAL/telesis/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>