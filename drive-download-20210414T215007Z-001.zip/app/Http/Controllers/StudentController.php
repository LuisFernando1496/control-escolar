<?php

namespace App\Http\Controllers;

use App\Actions\Fortify\PasswordValidationRules;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class StudentController extends Controller
{
    use PasswordValidationRules;

    public function create(){
        return view('auth.register');
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => $this->passwordRules(),
            'lastname1'=>['required','string', 'max:255'],
            'lastname2'=>['required', 'string', 'max:255'],
            'rfc'=>['string','min:13','max:13','nullable'],
            'key'=>['required','string', 'max:8'],
            'phone'=>['required','min:10','numeric','unique:users'],
            'sex'=>['required','boolean'],
            'birthday'=>['required','date'],
            'active'=>['required','boolean'],
            'roles'=>['required','array'],
            'isStudent'=>['boolean'],
            'paid'=>['nullable','boolean',Rule::requiredIf($request['isStudent'])],
            'address'=>['nullable','string', 'max:255',Rule::requiredIf($request['isStudent'])],
            'tutor'=>['nullable','string', 'max:255',Rule::requiredIf($request['isStudent'])],
            'blood_id'=> ['nullable','numeric',Rule::requiredIf($request['isStudent'])],
            'grade_id'=>['nullable','numeric', Rule::requiredIf($request['isStudent'])],
            'group_id'=>['nullable','numeric', Rule::requiredIf($request['isStudent'])]
        ]);
        $user = User::create([
            'name' =>strtolower($request['name']),
            'lastname1' => strtolower($request['lastname1']),
            'lastname2' =>strtolower($request['lastname2']),
            'rfc' =>strtoupper($request['rfc']),
            'key' => $request['key'],
            'phone' => $request['phone'],
            'sex' => $request['sex'],
            'birthday' => $request['birthday'],
            'active' => $request['active'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
        ]);
        $user->roles()->attach($request['roles']);
        if($request['isStudent']){
            $date = Carbon::now();
            $user->student()->create([
                'behaviour' => 10,
                'banned' => false,
                'end' => false,
                'banned_time' => NULL,
                'period'=>$date->format('Y-m-d'),
                'strikes' => 0,
                'paid' =>$request['paid'],
                'address' => $request['address'],
                'tutor' => $request['tutor'],
                'blood_id' => $request['blood_id'],
                'current_group_id' => $request['group_id'],
                'current_grade_id' => $request['grade_id'],
            ]);
            $user->student->records()->create([
                'grade_id'=>$request['grade_id'],
                'group_id'=>$request['group_id'],
                'score'=>-1
            ]);
            if(!$request['paid']){
                $user->update(['active'=>false]);
            }
        }
        return redirect()->route('students');
    }
}
